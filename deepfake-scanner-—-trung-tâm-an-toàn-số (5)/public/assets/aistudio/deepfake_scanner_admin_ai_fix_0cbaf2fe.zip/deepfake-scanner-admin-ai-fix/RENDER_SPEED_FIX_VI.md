# Bản vá tốc độ quét Gemini trên Render

## Những điểm đã chỉnh

- Thêm thời gian đo riêng cho model chính, model dự phòng và tổng thời gian xử lý của `/api/scan`.
- Giới hạn thời gian của mỗi lần gọi Gemini bằng cấu hình `httpOptions.timeout` của SDK, đồng thời tắt retry ngầm (`attempts: 1`) để không bị cộng dồn nhiều lần chờ.
- Chỉ thử model dự phòng một lần nếu lỗi có khả năng tạm thời hoặc tên model không hợp lệ/không khả dụng. Lỗi API key, quyền truy cập và yêu cầu sai không gọi thêm model không cần thiết.
- Giữ `thinkingBudget: 0`, giới hạn đầu ra cấu trúc ở 3.500 token và tắt automatic continuation để tránh phát sinh các lượt generate tiếp nối ngoài dự kiến.
- Log `ScanTiming` không chứa API key hoặc dữ liệu ảnh. Thành công sẽ ghi model thực tế, thời gian model chính/dự phòng, tổng thời gian và kích thước ảnh; fallback cũng ghi lý do.
- Dùng chung một Promise nén cho mỗi ảnh đã chọn, tránh nén lại khi người dùng bấm quét trước khi thông số nén kịp cập nhật giao diện.
- Thêm timeout 45 giây phía trình duyệt để không chờ vô hạn nếu kết nối bị treo.
- `/api/health` trả tên model và fallback model để giao diện hiển thị đúng cấu hình thực tế, thay vì ghi cứng tên model cũ.
- Chỉnh chữ giao diện để nêu rõ hiện chỉ nhận ảnh tĩnh/ảnh chụp khung hình video; chưa hỗ trợ tải trực tiếp MP4/MOV.

## Biến môi trường

- `GEMINI_MODEL`: model chính; hiện `render.yaml` đặt `gemini-3.8-flash`.
- `GEMINI_FALLBACK_MODEL`: model dự phòng; mặc định `gemini-2.5-flash`.
- `GEMINI_PRIMARY_TIMEOUT_MS`: thời gian chờ mỗi yêu cầu model chính; mặc định 18.000 ms.
- `GEMINI_FALLBACK_TIMEOUT_MS`: thời gian chờ model dự phòng; mặc định 10.000 ms.

Các timeout áp dụng cho từng lần gọi, không phải cam kết rằng mọi lần quét sẽ hoàn thành trong số giây đó. Nếu hai model lần lượt gặp lỗi/timeout, tổng thời gian vẫn có thể xấp xỉ tổng hai giới hạn cộng thời gian xử lý. Lỗi 503/429 từ Gemini vẫn có thể xảy ra do tải dịch vụ hoặc quota.

## Triển khai an toàn

1. Giải nén bản này vào thư mục mới; không ghi đè bản đang hoạt động.
2. Cài dependencies rồi chạy `npm run lint` và `npm run build` tại máy có kết nối npm registry.
3. Commit trên nhánh riêng và đẩy lên GitHub; chỉ merge sau khi build thành công.
4. Giữ nguyên `GEMINI_API_KEY` đã cấu hình trong Render; không thêm key vào GitHub hay `.env.example`.
5. Sau khi deploy, gọi `/api/health` để xác nhận trường `model`, sau đó thực hiện một lần quét thử.
6. Trong Render Logs, tìm `[ScanTiming] completed`, `[ScanTiming] primary model failed`, `[ScanTiming] fallback model failed` hoặc `[ScanTiming] using heuristic fallback` để biết độ trễ đến từ đâu.

## Lưu ý

Heuristic fallback là bộ quy tắc văn bản, không phân tích pixel ảnh và không xác minh đích đến của URL. Giao diện cần tiếp tục cảnh báo rõ khi kết quả đến từ fallback. Không diễn giải kết quả dự phòng như chứng cứ xác nhận ảnh thật/giả.

Bản vá này tối ưu luồng quét hiện có; không thêm tải video MP4/MOV trực tiếp hoặc tự động trích xuất khung hình từ video.


## Tài khoản User/Admin và PostgreSQL
Bản cập nhật có trang `#account`, API đăng ký/đăng nhập/đăng xuất, phân quyền admin và bảng quản lý người dùng. Trong Render Environment, đặt `DATABASE_URL` (Internal Database URL của Render PostgreSQL), `ADMIN_EMAIL` và `ADMIN_PASSWORD` (ít nhất 12 ký tự) để khởi tạo quản trị viên đầu tiên. Tự động tạo bảng `app_users`, `app_sessions`, `scan_audit`; các lần quét đã đăng nhập chỉ ghi metadata, không lưu ảnh/tin nhắn.

Thời gian AI mặc định là 18 giây cho model chính và 10 giây cho model dự phòng. Kiểm tra `[ScanTiming]` và `[ChatTiming]` trong Render Logs sau khi triển khai.
