# Hướng dẫn cập nhật User/Admin và giảm độ trễ AI trên Render

## 1. Có gì trong bản cập nhật

- Trang `#account`: đăng ký, đăng nhập, đăng xuất; tài khoản người dùng và dashboard admin.
- API tài khoản: `/api/auth/register`, `/api/auth/login`, `/api/auth/logout`, `/api/auth/me`, `/api/auth/scans`.
- API admin có kiểm tra quyền ở backend: `/api/admin/overview`, `/api/admin/users`, `/api/admin/scans`; chỉ admin mới xem dữ liệu quản trị và thay đổi role/status.
- PostgreSQL tự tạo các bảng `app_users`, `app_sessions`, `scan_audit` khi khởi động. Không lưu ảnh, video, tin nhắn hoặc nội dung riêng tư vào bảng lịch sử quét; chỉ lưu metadata/thời gian.
- Mật khẩu được băm bằng scrypt. Session là token ngẫu nhiên trong cookie HttpOnly/SameSite=Lax và chỉ lưu hash token trong DB.
- Hạn chế retry ngầm của SDK; timeout mặc định 18 giây cho model chính và 10 giây cho model dự phòng; output giới hạn để tránh câu trả lời quá dài; log `[ScanTiming]` và `[ChatTiming]`. Với Gemini 3.x, code dùng `thinkingLevel: low` và bỏ các tham số lấy mẫu cũ (`temperature`, `topP`, `topK`) để tránh lỗi cấu hình và giảm độ trễ.
- Nếu thiếu `DATABASE_URL`, chức năng quét vẫn chạy; chỉ chức năng tài khoản và admin bị vô hiệu hóa.

## 2. Cấu hình PostgreSQL và tài khoản Admin

1. Tạo một PostgreSQL database trên Render. Nếu database và Web Service cùng khu vực, ưu tiên **Internal Database URL**.
2. Vào Render Dashboard → Web Service `deepfake-scanner-safety-center` → **Environment**.
3. Thêm các biến môi trường sau (nhập giá trị, không thêm dấu ngoặc kép nếu Render không yêu cầu):

   | Key | Giá trị |
   |---|---|
   | `DATABASE_URL` | Internal Database URL từ Render PostgreSQL |
   | `ADMIN_EMAIL` | Email admin đầu tiên, ví dụ email của bạn |
   | `ADMIN_PASSWORD` | Mật khẩu mạnh, ít nhất 12 ký tự |
   | `GEMINI_PRIMARY_TIMEOUT_MS` | `18000` |
   | `GEMINI_FALLBACK_TIMEOUT_MS` | `10000` |
   | `GEMINI_FALLBACK_MODEL` | `gemini-2.5-flash` |

4. Giữ `GEMINI_API_KEY` chỉ trong Environment của Render. Không commit API key, mật khẩu admin hoặc `DATABASE_URL` vào GitHub.
5. Lưu các biến và deploy. Khi server kết nối PostgreSQL thành công, log sẽ có `[Postgres] Account tables are ready.`
6. Mở website và chọn **Đăng nhập**. Dùng `ADMIN_EMAIL` và `ADMIN_PASSWORD` để đăng nhập admin đầu tiên. Nếu đã tồn tại admin active trong `app_users`, hệ thống không tự đổi mật khẩu của tài khoản đó.
7. Người dùng khác tự đăng ký sẽ nhận role `user`. Admin có thể xem thống kê, gán role admin/user, khóa/mở tài khoản và xem metadata thời gian quét.

Nếu chưa cấu hình `DATABASE_URL`, không thể đăng ký/đăng nhập. Đây là chủ ý an toàn: hệ thống không tạo tài khoản hoặc quyền admin trong bộ nhớ tạm.

## 3. Đẩy lên GitHub an toàn

1. Tải và giải nén ZIP vào thư mục mới. Không chép file `.env` (nếu có) vào thư mục gửi lên GitHub.
2. Clone repository hiện có và tạo nhánh riêng:

   ```bash
   git clone https://github.com/lehuythevinh-byte/deepfake-scanner-render.git deepfake-scanner-admin-fix
   cd deepfake-scanner-admin-fix
   git switch -c feat/user-admin-ai-timeout
   ```

3. Sao chép các file trong ZIP vào bản clone để xem xét, nhưng so sánh `server.ts`, `src/App.tsx` và các file liên quan nếu nhánh hiện tại đã có một bản tích hợp tài khoản riêng.
4. Chạy:

   ```bash
   npm install
   npm run lint
   npm run build
   git diff --check
   git status
   ```

5. Nếu cả lint/build thành công, commit và push:

   ```bash
   git add .
   git diff --cached --check
   git commit -m "feat: add user admin and improve AI timeouts"
   git push -u origin feat/user-admin-ai-timeout
   ```

6. Mở Pull Request trên GitHub và kiểm tra khác biệt trước khi merge vào `main`. Đặc biệt bảo đảm không có `.env`, khóa API hoặc URL cơ sở dữ liệu trong thay đổi.

## 4. Xác nhận AI đã nhanh hơn

- Thực hiện một lần quét ảnh và một lần chat SafeBot.
- Trong Render → Logs, tìm `[ScanTiming]` hoặc `[ChatTiming]`.
- So sánh `primaryMs`, `fallbackMs`, `totalMs`, `engine` và thông báo lỗi.
- Nếu thấy `engine: "heuristic"`, Gemini đã thất bại hoặc hết thời gian chờ; kết quả đó chỉ là kiểm tra quy tắc văn bản và **không** phân tích pixel ảnh/đích liên kết. Không được coi nó như một kết luận giám định bằng AI.
- Với timeout mới, thời gian chờ phía AI thông thường được giới hạn khoảng 28 giây nếu cả model chính và model dự phòng đều chạm timeout; nếu lỗi trả về sớm, kết quả sẽ sớm hơn. Render cold start vẫn có thể làm lần mở đầu chậm.

## 5. Lưu ý về dữ liệu đã có

Bản này tạo bảng `app_users`, `app_sessions`, `scan_audit`. Nếu một phiên bản trước đã tạo các bảng tài khoản với tên hoặc cấu trúc khác, code này **không tự di chuyển** dữ liệu từ bảng cũ. Các bảng cũ vẫn được giữ nguyên; cần xem schema cũ trước khi viết migration. Đừng xóa database để thử nghiệm.
